/*** Sample Embedding Corticon JS Engine in browser ***/
window.corticonEngine.execute(payload);