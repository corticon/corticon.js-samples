# Garden Plant Issue Diagnosis Dynamic Form

[Download Rule Assets](https://github.com/corticon/templates/blob/main/Dynamic-Form-Templates/Plant-Clinic/Rule%20Assets.zip)

<iframe width="100%" height="700" src="//jsfiddle.net/salmelinovitz/3n198gqz/11/embedded/result/" allowfullscreen="allowfullscreen" allowpaymentrequest frameborder="0"></iframe>